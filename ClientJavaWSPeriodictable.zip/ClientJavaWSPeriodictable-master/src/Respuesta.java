/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author entrar
 */
public class Respuesta {
    private String ElementName;
    private String AtomicNumber;
    private String  Symbol;
    private String AtomicWeight;
    {
        
    }

    public Respuesta(String ElementName, String AtomicNumber, String Symbol, String AtomicWeight) {
        this.ElementName = ElementName;
        this.AtomicNumber = AtomicNumber;
        this.Symbol = Symbol;
        this.AtomicWeight = AtomicWeight;
    }
          
}
