package clientjavawsperiodictable;




import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root
public class NewDataSet3 {

    @Element
    private Table3 Table;
   
    public Table3 getTable() {
        return Table;
    }
 
    public void setTable(Table3 Table) {
        this.Table = Table;
    }
}