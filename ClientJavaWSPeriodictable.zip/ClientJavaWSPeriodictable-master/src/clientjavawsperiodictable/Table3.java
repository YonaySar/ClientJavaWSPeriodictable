package clientjavawsperiodictable;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;


@Root
public class Table3 {
    @Element
    private String AtomicWeight;

    public String getAtomicWeight() {
        return AtomicWeight;
    }

    public void setAtomicWeight(String AtomicWeight) {
        this.AtomicWeight = AtomicWeight;
    }
}
