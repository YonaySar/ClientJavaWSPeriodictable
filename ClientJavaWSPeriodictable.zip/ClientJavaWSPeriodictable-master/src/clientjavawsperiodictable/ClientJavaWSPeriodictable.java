/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientjavawsperiodictable;



import java.util.Iterator;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;
public class ClientJavaWSPeriodictable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     try {
         
            Serializer serializer = new Persister();//Persirter que utilizaremos para todos los metodos
          
          //Utilizamos el AtomicNumber
            String source = getAtomicNumber("Uranium");
            NewDataSet1 NewDataSet = new NewDataSet1();
            serializer.read(NewDataSet, source);
            
            System.out.println("El GetAtomicNumber para el Uranium nos muestra: ");
            System.out.println("Numero atomico: "+NewDataSet.getTable().getAtomicNumber());
            System.out.println("Elemento: " +NewDataSet.getTable().getElementName());
            System.out.println("Simbolo: "+ NewDataSet.getTable().getSymbol());
            System.out.println("Peso atomico: "+NewDataSet.getTable().getAtomicWeight());
            System.out.println("Punto de embullicion: "+NewDataSet.getTable().getBoilingPoint());
            System.out.println("Potencial de ionizacion: "+NewDataSet.getTable().getIonisationPotential());
            System.out.println("Electro Negatividad: "+NewDataSet.getTable().getEletroNegativity());
            System.out.println("Radio Atomico: "+NewDataSet.getTable().getAtomicRadius());
            System.out.println("Punto para derretir: "+NewDataSet.getTable().getMeltingPoint());
            System.out.println("Densidad: "+NewDataSet.getTable().getDensity()+"\n");
          
          //Utilizamos el ElementSymbol
  
            source = getElementSymbol("Scandium");
            NewDataSet2 NewDataSet2 = new NewDataSet2();
            serializer.read(NewDataSet2, source);
            System.out.println("El metodo GetElementsSymbol para el Scandium nos muestra: ");
            System.out.println("Simbolo: "+ NewDataSet2.getTable().getSymbol()+"\n");
            
          //Utilizamos el AtomicWeight  
          
            source = getAtomicWeight("Unununium");
            NewDataSet3 NewDataSet3 = new NewDataSet3();
            serializer.read(NewDataSet3, source);
            System.out.println("El metodo GetWeight para el Unununium nos muestra: ");
            System.out.println("Peso atomico: "+NewDataSet3.getTable().getAtomicWeight()+"\n");
            
          //Utilizamos el Atoms
          
            source= getAtoms();
            NewDataSet4 NewDataSet4 = new NewDataSet4();
            serializer.read(NewDataSet4, source);
            System.out.println("El metodo GetAtoms nos da: ");
            
            Iterator<Table4> it = NewDataSet4.get().iterator();
            while (it.hasNext()) {
            System.out.println(it.next().getElementName());
 
            }
         
        
        } catch (Exception e) {
        }
     
    }
    private static String getAtomicNumber(java.lang.String elementName) {
        net.webservicex.Periodictable service = new net.webservicex.Periodictable();
        net.webservicex.PeriodictableSoap port = service.getPeriodictableSoap();
        return port.getAtomicNumber(elementName);
    }

    private static String getAtomicWeight(java.lang.String elementName) {
        net.webservicex.Periodictable service = new net.webservicex.Periodictable();
        net.webservicex.PeriodictableSoap port = service.getPeriodictableSoap();
        return port.getAtomicWeight(elementName);
    }

    private static String getAtoms() {
        net.webservicex.Periodictable service = new net.webservicex.Periodictable();
        net.webservicex.PeriodictableSoap port = service.getPeriodictableSoap();
        return port.getAtoms();
    }

    private static String getElementSymbol(java.lang.String elementName) {
        net.webservicex.Periodictable service = new net.webservicex.Periodictable();
        net.webservicex.PeriodictableSoap port = service.getPeriodictableSoap();
        return port.getElementSymbol(elementName);
    }
  
}
