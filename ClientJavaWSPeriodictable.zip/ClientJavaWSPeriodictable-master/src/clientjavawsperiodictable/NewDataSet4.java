
package clientjavawsperiodictable;

import java.util.List;

import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

@Root(name = "NewDataSet")
public class NewDataSet4 {

    @ElementList(inline = true)
    private List<Table4> Table;

    
    public void set(List<Table4> Table) {
        this.Table = Table;
    }

    public List<Table4> get() {
        return Table;
    }
   
}